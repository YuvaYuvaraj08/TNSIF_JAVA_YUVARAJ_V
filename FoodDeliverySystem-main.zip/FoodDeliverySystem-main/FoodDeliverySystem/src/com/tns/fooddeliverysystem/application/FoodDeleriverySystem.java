package com.tns.fooddeliverysystem.application;
import com.tns.fooddeliverysystem.entities.*;
import com.tns.fooddeliverysystem.services.*;

import java.util.*;

public class FoodDeleriverySystem {
	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);

        // Shared data collections
        List<Restaurant> restaurants = new ArrayList<>();
        List<Customer> customers = new ArrayList<>();
        List<Order> orders = new ArrayList<>();
        List<DeliveryPerson> deliveryPersons = new ArrayList<>();

        // Services
        AdminService adminService = new AdminService(restaurants, deliveryPersons, orders);
        CustomerService customerService = new CustomerService(customers, restaurants, orders);
        OrderService orderService = new OrderService(orders);

        int mainChoice;
        do {
            System.out.println("\n========== ONLINE FOOD DELIVERY SYSTEM ==========");
            System.out.println("1. Admin Menu");
            System.out.println("2. Customer Menu");
            System.out.println("3. Exit");
            System.out.print("Choose an option: ");
            mainChoice = sc.nextInt();

            switch (mainChoice) {
                case 1 -> adminMenu(sc, adminService);
                case 2 -> customerMenu(sc, customerService);
                case 3 -> System.out.println("Exiting the system. Thank you!");
                default -> System.out.println("Invalid choice! Try again.");
            }

        } while (mainChoice != 3);
    }

    // ========================= ADMIN MENU =========================
    private static void adminMenu(Scanner sc, AdminService adminService) {
        int choice;
        do {
            System.out.println("\n===== Admin Menu =====");
            System.out.println("1. Add Restaurant");
            System.out.println("2. Add Food Item to Restaurant");
            System.out.println("3. Remove Food Item from Restaurant");
            System.out.println("4. View Restaurants and Menus");
            System.out.println("5. View Orders");
            System.out.println("6. Add Delivery Person");
            System.out.println("7. Assign Delivery Person to Order");
            System.out.println("8. Exit Admin Menu");
            System.out.print("Choose an option: ");
            choice = sc.nextInt();

            switch (choice) {
                case 1 -> {
                    System.out.print("Enter Restaurant ID: ");
                    int rid = sc.nextInt();
                    sc.nextLine();
                    System.out.print("Enter Restaurant Name: ");
                    String rname = sc.nextLine();
                    adminService.addRestaurant(rid, rname);
                }
                case 2 -> {
                    System.out.print("Enter Restaurant ID: ");
                    int rid = sc.nextInt();
                    System.out.print("Enter Food Item ID: ");
                    int fid = sc.nextInt();
                    sc.nextLine();
                    System.out.print("Enter Food Item Name: ");
                    String fname = sc.nextLine();
                    System.out.print("Enter Food Item Price: ");
                    double price = sc.nextDouble();
                    adminService.addFoodItemToRestaurant(rid, fid, fname, price);
                }
                case 3 -> {
                    System.out.print("Enter Restaurant ID: ");
                    int rid = sc.nextInt();
                    System.out.print("Enter Food Item ID to remove: ");
                    int fid = sc.nextInt();
                    adminService.removeFoodItemFromRestaurant(rid, fid);
                }
                case 4 -> adminService.viewRestaurantsAndMenus();
                case 5 -> adminService.viewOrders();
                case 6 -> {
                    System.out.print("Enter Delivery Person ID: ");
                    int did = sc.nextInt();
                    sc.nextLine();
                    System.out.print("Enter Delivery Person Name: ");
                    String dname = sc.nextLine();
                    System.out.print("Enter Contact No.: ");
                    long contact = sc.nextLong();
                    adminService.addDeliveryPerson(did, dname, contact);
                }
                case 7 -> {
                    System.out.print("Enter Order ID: ");
                    int oid = sc.nextInt();
                    System.out.print("Enter Delivery Person ID: ");
                    int did = sc.nextInt();
                    adminService.assignDeliveryPersonToOrder(oid, did);
                }
                case 8 -> System.out.println("Exiting Admin Module...");
                default -> System.out.println("Invalid choice! Try again.");
            }
        } while (choice != 8);
    }

    // ========================= CUSTOMER MENU =========================
    private static void customerMenu(Scanner sc, CustomerService customerService) {
        int choice;
        do {
            System.out.println("\n===== Customer Menu =====");
            System.out.println("1. Add Customer");
            System.out.println("2. View Food Items");
            System.out.println("3. Add Food to Cart");
            System.out.println("4. View Cart");
            System.out.println("5. Place Order");
            System.out.println("6. View Orders");
            System.out.println("7. Exit Customer Menu");
            System.out.print("Choose an option: ");
            choice = sc.nextInt();

            switch (choice) {
                case 1 -> {
                    System.out.print("Enter User ID: ");
                    int uid = sc.nextInt();
                    sc.nextLine();
                    System.out.print("Enter Username: ");
                    String uname = sc.nextLine();
                    System.out.print("Enter Contact No.: ");
                    long contact = sc.nextLong();
                    customerService.addCustomer(uid, uname, contact);
                }
                case 2 -> customerService.viewFoodItems();
                case 3 -> {
                    System.out.print("Enter Customer ID: ");
                    int cid = sc.nextInt();
                    System.out.print("Enter Restaurant ID: ");
                    int rid = sc.nextInt();
                    System.out.print("Enter Food Item ID: ");
                    int fid = sc.nextInt();
                    System.out.print("Enter Quantity: ");
                    int qty = sc.nextInt();
                    customerService.addFoodToCart(cid, rid, fid, qty);
                }
                case 4 -> {
                    System.out.print("Enter Customer ID: ");
                    int cid = sc.nextInt();
                    customerService.viewCart(cid);
                }
                case 5 -> {
                    System.out.print("Enter Customer ID: ");
                    int cid = sc.nextInt();
                    sc.nextLine();
                    System.out.print("Enter Delivery Address: ");
                    String address = sc.nextLine();
                    customerService.placeOrder(cid, address);
                }
                case 6 -> {
                    System.out.print("Enter Customer ID: ");
                    int cid = sc.nextInt();
                    customerService.viewCustomerOrders(cid);
                }
                case 7 -> System.out.println("Exiting Customer Module...");
                default -> System.out.println("Invalid choice! Try again.");
            }

        } while (choice != 7);
		
		}
}
