package com.tns.fooddeliverysystem.services;
import com.tns.fooddeliverysystem.entities.*;
import java.util.ArrayList;
import java.util.List;

@SuppressWarnings("unused")
public class AdminService {
    private List<Restaurant> restaurants;
    private List<DeliveryPerson> deliveryPersons;
    private List<Order> orders;

    public AdminService(List<Restaurant> restaurants, List<DeliveryPerson> deliveryPersons, List<Order> orders) {
        this.restaurants = restaurants;
        this.deliveryPersons = deliveryPersons;
        this.orders = orders;
    }

    // 1. Add a new restaurant
    public void addRestaurant(int id, String name) {
        restaurants.add(new Restaurant(id, name));
        System.out.println("Restaurant added successfully!");
    }

    // 2. Add a food item to a restaurant
    public void addFoodItemToRestaurant(int restaurantId, int itemId, String name, double price) {
        for (Restaurant r : restaurants) {
            if (r.getId() == restaurantId) {
                r.addFoodItem(new FoodItem(itemId, name, price));
                System.out.println("Food item added successfully!");
                return;
            }
        }
        System.out.println("Restaurant not found!");
    }

    // 3. Remove food item
    public void removeFoodItemFromRestaurant(int restaurantId, int foodItemId) {
        for (Restaurant r : restaurants) {
            if (r.getId() == restaurantId) {
                r.removeFoodItem(foodItemId);
                System.out.println("Food item removed successfully!");
                return;
            }
        }
        System.out.println("Restaurant not found!");
    }

    // 4. View restaurants and their menus
    public void viewRestaurantsAndMenus() {
        if (restaurants.isEmpty()) {
            System.out.println("No restaurants available!");
        } else {
            for (Restaurant r : restaurants) {
                System.out.println(r);
            }
        }
    }

    // 5. View all orders
    public void viewOrders() {
        if (orders.isEmpty()) {
            System.out.println("No orders placed yet.");
        } else {
            for (Order o : orders) {
                System.out.println(o);
            }
        }
    }

    // 6. Add delivery person
    public void addDeliveryPerson(int id, String name, long contactNo) {
        deliveryPersons.add(new DeliveryPerson(id, name, contactNo));
        System.out.println("Delivery person added successfully!");
    }

    // 7. Assign delivery person to order
    public void assignDeliveryPersonToOrder(int orderId, int deliveryPersonId) {
        Order order = null;
        for (Order o : orders) {
            if (o.getOrderId() == orderId) {
                order = o;
                break;
            }
        }
        if (order == null) {
            System.out.println("Order not found!");
            return;
        }

        for (DeliveryPerson d : deliveryPersons) {
            if (d.getDeliveryPersonId() == deliveryPersonId) {
                order.setDeliveryPerson(d);
                System.out.println("Delivery person assigned successfully!");
                return;
            }
        }
        System.out.println("Delivery person not found!");
    }
}
