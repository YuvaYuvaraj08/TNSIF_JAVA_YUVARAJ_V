package com.tns.fooddeliverysystem.services;
import com.tns.fooddeliverysystem.entities.*;
import java.util.*;

public class CustomerService {
    private List<Customer> customers;
    private List<Restaurant> restaurants;
    private List<Order> orders;
    private static int orderCounter = 1;

    public CustomerService(List<Customer> customers, List<Restaurant> restaurants, List<Order> orders) {
        this.customers = customers;
        this.restaurants = restaurants;
        this.orders = orders;
    }

    // 1. Add new customer
    public void addCustomer(int userId, String username, long contactNo) {
        customers.add(new Customer(userId, username, contactNo));
        System.out.println("Customer created successfully!");
    }

    // 2. View all food items from all restaurants
    public void viewFoodItems() {
        if (restaurants.isEmpty()) {
            System.out.println("No restaurants available!");
        } else {
            for (Restaurant r : restaurants) {
                System.out.println(r);
            }
        }
    }

    // 3. Add food to cart
    public void addFoodToCart(int customerId, int restaurantId, int foodItemId, int quantity) {
        Customer customer = getCustomerById(customerId);
        if (customer == null) {
            System.out.println("Customer not found!");
            return;
        }

        for (Restaurant r : restaurants) {
            if (r.getId() == restaurantId) {
                for (FoodItem item : r.getMenu()) {
                    if (item.getId() == foodItemId) {
                        customer.getCart().addItem(item, quantity);
                        System.out.println("Food item added to cart!");
                        return;
                    }
                }
            }
        }
        System.out.println("Food item or restaurant not found!");
    }

    // 4. View cart
    public void viewCart(int customerId) {
        Customer customer = getCustomerById(customerId);
        if (customer != null) {
            System.out.println(customer.getCart());
        } else {
            System.out.println("Customer not found!");
        }
    }

    // 5. Place order
    public void placeOrder(int customerId, String address) {
        Customer customer = getCustomerById(customerId);
        if (customer == null) {
            System.out.println("Customer not found!");
            return;
        }

        if (customer.getCart().getItems().isEmpty()) {
            System.out.println("Your cart is empty!");
            return;
        }

        Order newOrder = new Order(orderCounter++, customer);
        for (Map.Entry<FoodItem, Integer> entry : customer.getCart().getItems().entrySet()) {
            newOrder.addItem(entry.getKey(), entry.getValue());
        }
        newOrder.setDeliveryAddress(address);
        orders.add(newOrder);
        customer.getCart().getItems().clear(); // clear cart after placing order
        System.out.println("Order placed successfully! Your order ID is: " + newOrder.getOrderId());
    }

    // 6. View customer orders
    public void viewCustomerOrders(int customerId) {
        boolean found = false;
        for (Order o : orders) {
            if (o.getCustomer().getUserId() == customerId) {
                System.out.println(o);
                found = true;
            }
        }
        if (!found) System.out.println("No orders found for this customer.");
    }

    private Customer getCustomerById(int id) {
        for (Customer c : customers) {
            if (c.getUserId() == id) return c;
        }
        return null;
    }
}

