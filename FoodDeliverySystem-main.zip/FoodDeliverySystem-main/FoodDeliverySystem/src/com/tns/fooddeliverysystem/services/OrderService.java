package com.tns.fooddeliverysystem.services;
import com.tns.fooddeliverysystem.entities.*;
import java.util.List;

public class OrderService {
    private List<Order> orders;

    public OrderService(List<Order> orders) {
        this.orders = orders;
    }

    public void viewAllOrders() {
        if (orders.isEmpty()) {
            System.out.println("No orders found.");
        } else {
            for (Order o : orders) {
                System.out.println(o);
            }
        }
    }

    public void updateOrderStatus(int orderId, String status) {
        for (Order o : orders) {
            if (o.getOrderId() == orderId) {
                o.setStatus(status);
                System.out.println("Order status updated to: " + status);
                return;
            }
        }
        System.out.println("Order not found!");
    }
}
