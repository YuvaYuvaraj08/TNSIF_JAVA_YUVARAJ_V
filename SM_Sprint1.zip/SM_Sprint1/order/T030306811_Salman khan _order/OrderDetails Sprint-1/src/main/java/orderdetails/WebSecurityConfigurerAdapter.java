package orderdetails;

public class WebSecurityConfigurerAdapter {

	protected void configure(HttpSecurity http) throws Exception {
		// TODO Auto-generated method stub
		
	}

}
